import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BT = int(os.getenv("MAX_BOT", "250"))

DEVS 
= list(map(int, os.getenv("DEVS", "794782727.1").split()))

API_ID = int(os.getenv("API_ID", "29238634"))

API_HASH  os.getenv("API_HASH", "56edcb4368e1f7993b210695a81461a")

BOT_TOKE = os.geten


v("BOTOKEN", "8469669100:AAFo5QKh9ahh-F_zEwiSMNtzCAjngGdAxIM")

OWNER_ID = int(os.getenv("OWNER_ID", "7947827271"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002312835928").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://zaaytofficial:4MMbEVZLHFBXwbLB@cluster0.mspnbis.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-100329896418"))
